import multiprocessing as mp, os
from functools import partial
mp.set_start_method("spawn", force=True)      # or "forkserver"
import psutil
import threading
import time
import functools
# (optional) keep one BLAS thread per worker
os.environ["OMP_NUM_THREADS"]      = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"]      = "1"

from scipy.sparse import dia_array, csr_array, eye, diags as diags_array
import matplotlib
import matplotlib.pyplot as plt
from scipy.sparse.linalg import eigs, spsolve
from scipy.sparse import identity, csr_matrix
import time

import matplotlib.animation
from mpl_toolkits.axes_grid1 import make_axes_locatable
#import networkx as nx
#import optax
from copy import deepcopy
import datetime
import scipy.sparse as sps
#from interpax import interp2d
import pickle
from fractions import Fraction
from math import gcd,ceil
from functools import reduce
#import pygmo as pg
import matplotlib.patches as patches
import matplotlib.ticker as ticker
from matplotlib.colors import LinearSegmentedColormap
import random as rnd

import numpy as np
import matplotlib.pyplot as plt
import os
#import optax
from copy import deepcopy
import datetime
import scipy.sparse as sps
from scipy import sparse
from matplotlib.patches import Rectangle, Circle


import pickle
try:
    os.chdir('/home/openam/Desktop/Nate/convexPreopt')
    #os.chdir('/home/hal90000/Desktop/Nate/2DSDPTMM')
    #os.chdir('/home/groundnet/Desktop/Nate/convexPreopt')
except:
    pass
#from microwaveTradLocalCore.sdpunited_microwavesdp2trad import *
from matplotlib.colors import ListedColormap
import time
import multiprocessing as mp
import subprocess
import scipy.io
from scipy.sparse import csc_matrix, csr_matrix, coo_matrix, spmatrix
import sys

from collections import defaultdict
from mpl_toolkits.axes_grid1 import make_axes_locatable
#%env XLA_PYTHON_CLIENT_PREALLOCATE=false
def monitor_resources(log_list, stop_event, interval=0.5):
    parent = psutil.Process()
    while not stop_event.is_set():
        # Update the list of children each time to capture new subprocesses
        children = parent.children(recursive=True)
        all_procs = [parent] + children

        cpu = sum(p.cpu_percent(interval=None) for p in all_procs if p.is_running())
        mem = sum(p.memory_info().rss for p in all_procs if p.is_running())

        log_list.append((time.time(), cpu, mem))
        time.sleep(interval)
        

def log_resources_during(func=None, *, interval=0.5):
    def decorator(f):
        @functools.wraps(f)
        def wrapper(*args, **kwargs):
            log = []
            stop_event = threading.Event()
            monitor_thread = threading.Thread(target=monitor_resources, args=(log, stop_event, interval))
            monitor_thread.start()

            try:
                result = f(*args, **kwargs)
            finally:
                stop_event.set()
                monitor_thread.join()
            return result, log
        return wrapper

    # Allow both @decorator and @decorator(...)
    if func is not None:
        return decorator(func)
    return decorator
#@title MicropatchSim
class micropatchSim:
    def __init__(self):
        """
        Simulates a 2D array of 4-port lumped elements with known S-matrices

        Indexing is a tad complex. For a 2x2 array, for example, we have:
                    y=            0         1                2              3         4
             x=                             |                               |
               0             e[0]=a_{0,1} v |                e[2]=a_{0,3} v |
                             ^ e[1]=b_{0,1} |                ^ e[3]=b_{0,3} |
                                            |                               |
                          e[4]=a_{1,0} >    |        e[6]=a_{1,2} >         |    e[8]=a_{1,4} >
               1       ------------------S_{1,1}-------------------------S_{1,3}----------------
                          < e[5]=b_{1,0}    |        < e[7]=b_{1,2}         |    < e[9]=b_{1,4}
                                            |                               |
               2            e[10]=a_{2,1} v |               e[12]=a_{2,3} v |
                            ^ e[11]=b_{2,1} |               ^ e[13]=b_{2,3} |
                                            |                               |
                         e[14]=a_{3,0} >    |       e[16]=a_{3,2} >         |   e[18]=a_{3,4} >
               3       ------------------S_{3,1}-------------------------S_{3,3}----------------
                         < e[15]=b_{3,0}    |       < e[17]=b_{3,2}         |   < e[19]=b_{3,4}
               4                            |                               |
                            e[20]=a_{4,1} v |               e[22]=a_{4,3} v |
                            ^ e[21]=b_{4,1} |               ^ e[23]=b_{4,3} |
                                            |                               |

        Attributes:
            e: Dict. e[freq][i] is the ith field at frequency freq. Fields are indexed sequenctially by x-coordinate, then by y-coordinate.
        """
        self.sMats={}
        self.tMats={}
        self.freqs=[]
        self.e={}
        self.weights={}
        self.setName=0
        self.nodeMap=[]
        self.ni=1
        self.augBoundary=False
        self.plotSize=None
        self.useSparse=False
        return

    def load_sMatrix(self,path,setName=None,symmetrize=True):
        """
        Loads the S-matrix located in a touchstone file at path. Assumes 4x4, arbitrary number of frequencies, 8 header lines.
        S_matrix convention is         Port 1
                                        | |                     a is always right and down, b is always left and up
                               Port 3 ¯¯   ¯¯ Port 2            S.<a1,b2,a3,b4>=<b1,a2,b3,a4> -> T.<a1,b1,a3,b3>=<a4,b4,a2,b2>
                                      ¯¯| |¯¯
                                       Port 4
        Arguments:
        path: String. Path to the touchstone file. Include directory and extension
        setName: Int. The index of this set of matrices. If None, will be assigned the next integer.
        symmetrize: Bool. If True, will symmetrize the S-matrix assuming four-fold symmetry, so only three independent elements which will be computed via averaging
        """
        if setName is None: #Generate a set name if none was provided
            setName=deepcopy(self.setName)
            self.setName+=1
        self.sMats[setName],self.tMats[setName]={},{}
        f=open(path,'r')
        v=f.readline()
        while True: #Get rid of the header lines
            vs=v.split()
            try:
                float(vs[0])
                break
            except:
                v=f.readline()
        matRow,cFreq=0,0
        while v!='': #Run through the actual matrices
            vs=v.split()
            if len(vs)==9: #Most lines have 8 numbers, real/im components of S_{i,0} through S_{i,4}. The first line has an additional number, that being the frequency of the S-matrix.
                cFreq=float(vs[0])
                self.sMats[setName][cFreq]=np.zeros((4,4),dtype=np.complex64)
                matRow=0
                vs.pop(0)
            self.sMats[setName][cFreq][matRow,:]=np.array([float(vs[0])+1j*float(vs[1]),float(vs[2])+1j*float(vs[3]),float(vs[4])+1j*float(vs[5]),float(vs[6])+1j*float(vs[7])])
            matRow+=1
            v=f.readline()
        f.close()
        for fr in self.sMats[setName].keys(): #Now we symmetrize if necessary, as well as compile the list of frequencies.
            sm=(self.sMats[setName][fr])
            sms=sm.shape[0]
            if symmetrize: #The S-matrix for a 4-port device with four-fold symmetry should be                              #[ a   b   b   c ]  Due to numerical dispersion, it will not actually be this.
                a=np.average([sm[i,i] for i in range(sms)])                                                                 #[ b   a   c   b ]  Average over like elements to make it fully symmetric.
                b=np.average([np.average([sm[i,j] for i in range(sms) if (i!=j and i!=(sms-1-j))]) for j in range(sms)])    #[ b   c   a   b ]
                c=np.average([sm[i,sms-1-i] for i in range(sms)])                                                           #[ c   b   b   a ]
                self.sMats[setName][fr]=np.ones_like(self.sMats[setName][fr])*b
                for i in range(sms):
                    self.sMats[setName][fr][i,i]=a
                    self.sMats[setName][fr][i,sms-1-i]=c
            self.freqs.append(fr)
        return

    def set_structure(self,xElements,yElements,setMap=None,symmetryAxis=None):
        """
        Sets the overall structure

        Arguments:
        xElements: Integer. Number of micropatches in the x-direction (row of matrix in python speak). If symmetry is not None, this should be the number of patches ON BOTH SIDEs
        yElements: Integer. Number of micropatches in the y-direction (column of matrix in python speak). If symmetry is not None, this should be the number of patches ON BOTH SIDEs
        setMap: Array-like. Which set of S/T-matrices to use at each node. setMap[i][j]=some Int, the index of one of the matrix sets
        symmetryAxis: String or None. If None, no symmetery. If 'x', the structure will be assumed symmetric along the central x-axis. If 'y', the structure will be assumed symmetric along the central y-axis.
        """
        self.symmetryAxis=symmetryAxis
        self.oddAxisX,self.oddAxisY=0,0
        if symmetryAxis=='x': #If we have symmetry along x (so bisects the y-axis)
            self.oddAxisX=int(yElements%2) #We have an odd axis if we have an odd number of elements in the y-direction, meaning it bisects one or more elements
            yElements=int(np.ceil(yElements/2)) #Remove the symmetrized elements from the simulation
        elif symmetryAxis=='y': #Dido for symmetry along y
            self.oddAxisY=int(xElements%2)
            xElements=int(np.ceil(xElements/2))
        self.xElements=xElements
        self.yElements=yElements
        self.Adim=self.xElements*self.yElements*2*2+self.xElements*2*(1-self.oddAxisX)+self.yElements*2*(1-self.oddAxisY) #Each node has its right and down branches, and the left and top boundaries have nodes as well. The left boundaries have no nodes if it is a y-direction odd axis, and the top boundaries have no nodes if it is an x-direction odd axis, since these bisect the waveguides/patches
        if setMap is None: #If the user has not specified a set of matrices, choose a random one and use it for all elements
            setKey=list(self.sMats.keys())[0]
            setMap=np.ones((xElements,yElements),dtype=int)*setKey
        self.setMap=setMap
        self.eX,self.eY=np.array(list(range(0,self.xElements*2+1,2))),np.array(list(range(0,self.yElements*2+1-self.oddAxisX,2))) #x,y for even columns (y even)
        self.oX,self.oY=np.array(list(range(1,self.xElements*2+1-self.oddAxisY,2))),np.array(list(range(1,self.yElements*2+1,2))) #x,y for odd columns (y odd)
        self._vector2arrayBuilder()
        return

    def set_boundary(self,boundaryMap):
        """
        Sets global boundary constraints.

        Arguments:
        boundaryMap: Dictionary. Each key is an (x,y) coordinate pair representing a boundary node. Each entry is either:
                     >a tuple ("input",v) where v is a scalar representing the complex amplitude of the wave incident on node (x,y)
                     >a tuple ("scatter",v) where v is a scalar representing the ratio of incident to transmitted wave; transmitted = v*incident
                     >a tuple ("connection",l,s) where l is a list of (x',y') tuples representing nodes connected to (x,y) and s is the scattering matrix among them (fields ordered in matrix as they appear in list, with key first. S-matrix maps in fields to out fields)
                     Any node not represented in the dictionary will be assumed open, such that transmitted = -incident (remember your phase shifts!)
                     Including nodes which are cut off by symmetry is optional, and will affect nothing. Nodes to the left of/below the line of symmetry take precedence.
        """
        baseScatter=1
        if self.augBoundary:
            airVals=self.sMats[0][self.freqs[0]]
            x,y,z=airVals[0,0],airVals[0,1],airVals[0,-1]
            baseScatter=(x-z)*(x**2-4*y**2+2*x*z+z**2)/(x**2-2*y**2+x*z)
            #baseScatter=(x**3+x**2*(z-2)-(z-1)*z**2+y**2*(2+4*z)-x*(-1+4*y**2+z+z**2))/(1+x**2-2*y**2+x*(z-2)-z)
        for k in boundaryMap.keys(): #Check for 'connection' type boundary conditions, and propagate them to all connected nodes
            if boundaryMap[k][0]=='connection':
                bcv=boundaryMap[k]
                for li in range(1,len(bcv[1])+1):
                    boundaryMap[bcv[1][li]]=("connection",[k,]+bcv[1],bcv[2][li])
                boundaryMap[k]=("connection",[k,]+bcv[1],bcv[2][0])
                #At this point, "connection" boudnaries have 1 entry per connected node, with entry[1] being the list of all connected nodes and entry[2] being the row of the S-matrix associated with that node.
        bMkeys=list(boundaryMap.keys())
        self.boundaryMap={}
        for y in self.oY: #Run through all odd ys (columns with top/bottom outputs)
            if (0,y) in bMkeys: #If the user has specified a boundary condition for the nodes along the bottom of the structure, use it. Otherwise, default to an open condition (scatter=1 means a=-b)
                self.boundaryMap[(0,y)]=boundaryMap[(0,y)]
            else:
                self.boundaryMap[(0,y)]=("scatter",baseScatter)
            if (2*self.xElements,y) in bMkeys: #Dido for the nodes along the top of the structure
                self.boundaryMap[(2*self.xElements,y)]=boundaryMap[(2*self.xElements,y)]
            else:
                if self.symmetryAxis=='y': #If the bisection passes between lumped elements, then we want a=b along these nodes, as the b comes from the a in the symmetric component.
                    if not bool(self.oddAxisY):
                        self.boundaryMap[(2*self.xElements,y)]=("scatter",-1)
                    else:
                        pass
                else:
                    self.boundaryMap[(2*self.xElements,y)]=("scatter",baseScatter)
        for x in self.oX: #Dido for the left/right sides of the structure
            if (x,0) in bMkeys:
                self.boundaryMap[(x,0)]=boundaryMap[(x,0)]
            else:
                self.boundaryMap[(x,0)]=("scatter",baseScatter)
            if (x,self.yElements*2) in bMkeys:
                self.boundaryMap[(x,self.yElements*2)]=boundaryMap[(x,self.yElements*2)]
            else:
                if self.symmetryAxis=='x':
                    if not bool(self.oddAxisX):
                        self.boundaryMap[(x,self.yElements*2)]=("scatter",-1)
                    else:
                        pass
                else:
                    self.boundaryMap[(x,self.yElements*2)]=("scatter",baseScatter)
        return

    def _vector2arrayBuilder(self):
        """
        Builds the vector to array map.

        v2a[floor(i/2)]=(x,y) location of element i in e.
        a2v[(x,y)]= index i of the a-field at location (x,y)
        """
        self.v2a,self.a2v={},{}
        self.v2aN,self.a2vN={},{}
        j=0
        for x in range(0,self.xElements*2+1-self.oddAxisY):
            for y in range((x+1)%2,self.yElements*2+1-self.oddAxisX,2):
                self.a2v[(x,y)]=j*2
                self.v2a[j]=(x,y)
                j+=1
        j=0
        for x in range(1,self.xElements*2+1-self.oddAxisY,2):
            for y in range(1,self.yElements*2+1-self.oddAxisX,2):
                self.a2vN[(x,y)]=j
                self.v2aN[j]=(x,y)
                j+=1
        return

    def _array2vector(self,coords):
        """
        Converts an (x,y) coordinate point into a vector index for the concatenated fields. Gives the position of the a-element
        """
        return int(np.ceil(coords[0]/2)*self.yElements+np.floor(coords[0]/2)*(self.yElements+1-self.oddAxisX)+np.ceil((coords[1]+1)/2)-1)*2

    def _vector2array(self,ind):
        """
        Converts a vector index for the concatenated fields into an (x,y) coordinate point.
        """
        eInd=int(np.floor(ind/2))
        return self.v2a[eInd]

    def _checkTup(self,field,fieldInd=0):
        """
        Checks if field is a tuple, and if it isn't, converts it to a coordinate pair.
        """
        if not hasattr(field,'__iter__'):
            field=self._vector2array(field//2)
            fieldInd=field%2
        return field,fieldInd


    def _boundaryField2Node(self,field):
        """
        Returns the node boardering a boundary field. Returns None if not a boundary field

        Arguments:
        field: Tuple or int. If tuple, the (x,y) coordinates of the field. If int, the vector index of the field.
        """
        field,_=self._checkTup(field)
        if field[0]==0:
            return (1,field[1])
        elif field[0]==2*self.xElements:
            return (2*self.xElements-1,field[1])
        elif field[1]==0:
            return (field[0],1)
        elif field[1]==2*self.yElements:
            return (field[0],2*self.yElements-1)
        else:
            return None

    def _ioc(self,node,field,fieldInd=0):
        """
        Tests if the field is going into or out of node. Returns True if in, False if out, None if not neighboring

        Arguments:
        node: Tuple. (x,y) coordinates of the node. Both x and y must be odd.
        field: Tuple or int. If tuple, the (x,y) coordinates of the field. If int, the vector index of the field.
        fieldInd: int. Only used if field is a tuple. 0 means the first field at (x,y) ('a') and 1 means the second ('b').
        """
        field,fieldInd=self._checkTup(field,fieldInd)
        if (node[1]==field[1]-1) ^ (node[0]==field[0]-1):
            return bool(fieldInd)
        elif (node[0]==field[0]+1) ^ (node[1]==field[1]+1):
            return not bool(fieldInd)
        else:
            return None


    def _processBoundary(self,bnd,field):
        """
        Processes a boundaryMap entry

        Arguments:
        bnd: Tuple. Entry of boundaryMap.
        field: Tuple. Key of boundaryMap.
        """
        node=self._boundaryField2Node(field)
        vi=self._array2vector(field)
        aIn=self._ioc(node,field,fieldInd=0)
        rv=np.zeros(self.Adim,dtype=np.complex64)
        if bnd[0]=='input':
            rv[vi:(vi+2)]+=np.array([1/bnd[1]*int(aIn),1/bnd[1]*int(not aIn)]) #Here, we set the coeff of the input wave to 1/desired input amplitude, so in the source vector we simply add a 1 for this row; (1/amp)*f=1 -> f=amp
            sourceV=1
        elif bnd[0]=='scatter':
            rv[vi:(vi+2)]+=np.array((bnd[1]*int(aIn)-int(not aIn),bnd[1]*int(not aIn)-int(aIn)))
            sourceV=0
        elif bnd[0]=='connection':
            incidents=[self._array2vector(ff)+int(self._ioc(self._boundaryField2Node(ff),ff,fieldInd=1)) for ff in bnd[1]] #array2vector gives the coordinate of the a-field. ioc will return 0 if a is the input, and 1 if b is the input.
            output=vi+int(aIn) #The out field of this row is the out amplitude of the current field. If aIn is True, a is the input, and aIn is 1, so the output is b (1+vi)
            rv[incidents]=np.array(bnd[2])
            rv[output]=-1
            sourceV=0
        elif bnd[0]=='output':
            rv[vi:(vi+2)]+=np.array((int(aIn),int(not aIn)))
            sourceV=0
        return rv,sourceV

    def compile_structure_sparse(self, freq):
        """
        Builds the system matrix at a given frequency by assembling COO lists
        and converting to CSR, with explicit loops to ensure exact value placement.
        """
        # Choose the nearest frequency
        chosenFreqi = np.argmin(np.abs(np.array(self.freqs) - freq))
        chosenFreq  = self.freqs[chosenFreqi]

        # Prepare COO accumulation lists and RHS
        rows, cols, data = [], [], []
        self.J = np.zeros(self.Adim, dtype=np.complex128)

        k = 0

        # 1) Upper boundary rows
        for y in range(1, self.yElements*2+1-self.oddAxisX, 2):
            rv, src = self._processBoundary(self.boundaryMap[(0, y)], (0, y))
            nz = np.nonzero(rv)[0]
            for idx in nz:
                rows.append(k)
                cols.append(int(idx))
                data.append(rv[idx])
            self.J[k] = src
            self.nodeMap.append(0)
            k += 1

        # 2) Left boundary + interior
        for x in range(1, self.xElements*2+1-self.oddAxisY, 2):
            # Left boundary at (x,0)
            rv, src = self._processBoundary(self.boundaryMap[(x, 0)], (x, 0))
            nz = np.nonzero(rv)[0]
            for idx in nz:
                rows.append(k)
                cols.append(int(idx))
                data.append(rv[idx])
            self.J[k] = src
            self.nodeMap.append(0)
            k += 1

            # Interior 4-port nodes
            for y in range(0, (self.yElements-1)*2+1, 2):
                # Compute inlet/outlet indices
                vU = self._array2vector((x-1, y+1))
                vR = self._array2vector((x,   y+2))
                vL = self._array2vector((x,   y  ))
                vD = self._array2vector((x+1, y+1))
                ins  = [vU, vR+1, vL,   vD+1]
                outs = [vU+1, vR,   vL+1, vD  ]

                sMat = self.sMats[self.setMap[x//2, y//2]][chosenFreq]

                # X-axis symmetry: 3×3 reduced block
                if self.symmetryAxis=='x' and self.oddAxisX and y==(self.yElements-1)*2:
                    # Build 3×3 S
                    s3 = np.array([
                        (sMat[0,0], sMat[0,1]+sMat[0,2], sMat[0,3]),
                        (sMat[1,0], sMat[1,1]+sMat[1,2], sMat[1,3]),
                        (sMat[3,0], sMat[3,1]+sMat[3,2], sMat[3,3]),
                    ], dtype=np.complex128)
                    # Reduced connectivity
                    ins_x  = [ins[i] for i in (0,2,3)]
                    outs_x = [outs[i] for i in (0,2,3)]
                    # Assemble
                    for i in range(3):
                        for j in range(3):
                            rows.append(k + i)
                            cols.append(ins_x[j])
                            data.append(s3[i,j])
                        rows.append(k + i)
                        cols.append(outs_x[i])
                        data.append(-1.0+0j)
                    self.nodeMap += [self.ni] * 3
                    self.ni    += 1
                    k        += 3

                # Y-axis symmetry: 3×3 reduced block
                elif self.symmetryAxis=='y' and self.oddAxisY and x==(self.xElements*2-self.oddAxisY):
                    s3 = np.array([
                        (sMat[0,0]+sMat[0,3], sMat[0,1], sMat[0,2]),
                        (sMat[1,0]+sMat[1,3], sMat[1,1], sMat[1,2]),
                        (sMat[2,0]+sMat[2,3], sMat[2,1], sMat[2,2]),
                    ], dtype=np.complex128)
                    ins_y  = [ins[i] for i in (0,1,2)]
                    outs_y = [outs[i] for i in (0,1,2)]
                    for i in range(3):
                        for j in range(3):
                            rows.append(k + i)
                            cols.append(ins_y[j])
                            data.append(s3[i,j])
                        rows.append(k + i)
                        cols.append(outs_y[i])
                        data.append(-1.0+0j)
                    self.nodeMap += [self.ni] * 3
                    self.ni    += 1
                    k        += 3

                # Default: full 4×4 block
                else:
                    for i in range(4):
                        for j in range(4):
                            rows.append(k + i)
                            cols.append(ins[j])
                            data.append(sMat[i,j])
                        rows.append(k + i)
                        cols.append(outs[i])
                        data.append(-1.0+0j)
                    self.nodeMap += [self.ni] * 4
                    self.ni    += 1
                    k        += 4

            # Far-right boundary if not oddAxisX
            if not bool(self.oddAxisX):
                rv, src = self._processBoundary(
                    self.boundaryMap[(x, self.yElements*2)],
                    (x, self.yElements*2)
                )
                nz = np.nonzero(rv)[0]
                for idx in nz:
                    rows.append(k)
                    cols.append(int(idx))
                    data.append(rv[idx])
                self.J[k] = src
                self.nodeMap.append(0)
                k += 1

        # Bottom boundary if not oddAxisY
        if not bool(self.oddAxisY):
            for y in range(1, self.yElements*2+1-self.oddAxisX, 2):
                rv, src = self._processBoundary(
                    self.boundaryMap[(self.xElements*2, y)],
                    (self.xElements*2, y)
                )
                nz = np.nonzero(rv)[0]
                for idx in nz:
                    rows.append(k)
                    cols.append(int(idx))
                    data.append(rv[idx])
                self.J[k] = src
                self.nodeMap.append(0)
                k += 1

        A_coo = sps.coo_matrix((data, (rows, cols)),
                              shape=(self.Adim, self.Adim),
                              dtype=np.complex128)
        self.A = A_coo.tocsr()
        return

    def compile_structure(self,freq):
        """
        Builds the system matrix at a given frequency

        Arguments:
        freq: Float. Frequency of the selected S-matrix. The closest frequency to the entered one will be used.
        """
        chosenFreqi=np.argmin(np.abs(np.array(self.freqs)-freq)) #Find the closest frequency to the one requested
        chosenFreq=self.freqs[chosenFreqi]
        self.A=np.zeros((self.Adim,self.Adim),dtype=np.complex64)
        self.J=np.zeros(self.Adim,dtype=np.complex64)
        nI=-np.identity(4,dtype=np.complex64)
        nI3=-np.identity(3,dtype=np.complex64)
        k=0
        for y in range(1,self.yElements*2+1-self.oddAxisX,2): #Run through the upper boundaries
            #print('Processing boundary at '+str((0,y))+', with boundaryMap '+str(self.boundaryMap[(0,y)]))
            self.A[k,:],self.J[k]=self._processBoundary(self.boundaryMap[(0,y)],(0,y))
            self.nodeMap.append(0)
            k+=1
        for x in range(1,self.xElements*2+1-self.oddAxisY,2): #Run through all the odd x, which are in-line with the lumped elements (even x have no associated element)
            #print('Processing boundary at '+str((x,0))+', with boundaryMap '+str(self.boundaryMap[(x,0)]))
            self.A[k,:],self.J[k]=self._processBoundary(self.boundaryMap[(x,0)],(x,0)) #Process the leftmost boundary
            self.nodeMap.append(0)
            k+=1
            for y in range(0,(self.yElements-1)*2+1,2): #Run through all the y's
                vU,vR,vL,vD=self._array2vector((x-1,y+1)),self._array2vector((x,y+2)),self._array2vector((x,y)),self._array2vector((x+1,y+1)) #a-coordinates of field on top (Port 1), right (Port 2), left (Port 3), and bottom (Port 4) of the node (node is i=x, j=y+1)
                ins=[vU,vR+1,vL,vD+1]#The index of the fields going into the node
                outs=[vU+1,vR,vL+1,vD]#The index of the fields going out of the node
                #print('Processing interior at '+str((x,y))+' with in-indices '+str(ins)+' and out-indices '+str(outs)+' and node '+str([int(np.floor(x/2)),int(np.floor(y/2))])+'. x-bisection condition is y=='+str((((self.yElements-1)*2+1)-((self.yElements-1)*2+1)%2))+'. y-bisection condition is x=='+str((self.xElements*2+1-self.oddAxisY-2)+1))
                sMat=self.sMats[self.setMap[int(np.floor(x/2)),int(np.floor(y/2))]][chosenFreq] #Get the appropriate S-matrix
                if self.symmetryAxis=='x' and self.oddAxisX and y==((self.yElements-1)*2+1)-((self.yElements-1)*2+1)%2: #If we have x-direction symmetry and this element falls on an odd axis
                    sMat=np.array(((sMat[0,0],sMat[0,1]+sMat[0,2],sMat[0,3]),(sMat[1,0],sMat[1,1]+sMat[1,2],sMat[1,3]),(sMat[3,0],sMat[3,1]+sMat[3,2],sMat[3,3])))
                    ins.pop(1)                  #Then we reduce the matrix to [ a   2b   c ]
                    outs.pop(1)                 #                             [ b   a+c  b ]
                    self.A[k:(k+3),ins]+=sMat   #                             [ c   2b   a ]
                    self.A[k:(k+3),outs]+=nI3
                    self.nodeMap+=[self.ni,self.ni,self.ni]
                    self.ni+=1
                    k+=3
                    #print('Went to bisection along y, new in-indices are '+str(ins)+' and out-indices '+str(outs))
                elif self.symmetryAxis=='y' and self.oddAxisY and x==(self.xElements*2+1-self.oddAxisY-2)+1: #Dido for y-direction symmetry
                    sMat=np.array(((sMat[0,0]+sMat[0,3],sMat[0,1],sMat[0,2]),(sMat[1,0]+sMat[1,3],sMat[1,1],sMat[1,2]),(sMat[2,0]+sMat[2,3],sMat[2,1],sMat[2,2])))
                    ins.pop(-1)                  #Then we reduce the matrix to [ a+c  b  b ]
                    outs.pop(-1)                 #                             [ b+b  a  c ]
                    self.A[k:(k+3),ins]+=sMat    #                             [ b+b  c  a ]
                    self.A[k:(k+3),outs]+=nI3
                    self.nodeMap+=[self.ni,self.ni,self.ni]
                    self.ni+=1
                    k+=3
                    #print('Went to bisection along y, new in-indices are '+str(ins)+' and out-indices '+str(outs))
                else: #Otherwise, plug in the entire matrix
                    #print('Went to default operation, full S-matrix')
                    self.A[k:(k+4),ins]+=sMat
                    self.A[k:(k+4),outs]+=nI
                    self.nodeMap+=[self.ni,self.ni,self.ni,self.ni]
                    self.ni+=1
                    k+=4
            if not bool(int(self.oddAxisX)): #If we do not have an odd x-symmetric axis, do the far right boundary nodes
                #print('Processing boundary at '+str((x,self.yElements*2))+', with boundaryMap '+str(self.boundaryMap[(x,self.yElements*2)]))
                self.A[k,:],self.J[k]=self._processBoundary(self.boundaryMap[(x,self.yElements*2)],(x,self.yElements*2))
                self.nodeMap.append(0)
                k+=1
        if not bool(int(self.oddAxisY)): #If we do not have an odd y-symmetric axis, do the lower boundary nodes
            for y in range(1,self.yElements*2+1-self.oddAxisX,2):
                #print('Processing boundary at '+str((self.xElements*2,y))+', with boundaryMap '+str(self.boundaryMap[(self.xElements*2,y)]))
                self.A[k,:],self.J[k]=self._processBoundary(self.boundaryMap[(self.xElements*2,y)],(self.xElements*2,y))
                self.nodeMap.append(0)
                k+=1
        if self.useSparse:
            self.A=sps.csr_matrix(self.A)
        return

    @log_resources_during(interval=0.5)
    def solve_system(self,freqs=[1.0]):
        """
        Runs a frequency sweep

        Arguments:
        freqs: List. List of frequencies to sweep. Each set of matrices represented in setMap should have a matrix at the given frequency.
        """
        if not hasattr(freqs,'__iter__'):
            freqs=[freqs]
        self.ts=[]
        for ff in freqs:
            t0=time.perf_counter()
            if not self.useSparse:
                self.compile_structure(ff)
                self.e[ff]=np.linalg.solve(self.A,self.J)
                
            else:
                self.compile_structure_sparse(ff)
                self.e[ff]=sps.linalg.spsolve(self.A,self.J,use_umfpack=True)
            self.ts.append(time.perf_counter()-t0)
        return

    def graph_system(self):
        """
        Converts the simulation results to a networkx graph for visualization/analysis. Access the graphs (one per frequency) as elements of the dictionary self.Gs.
        """
        self.Gs={}
        for ff in self.e.keys():
            self.Gs[ff]=nx.DiGraph()
            self.pos={}
            self.labelDict={}
            for i in sorted(list(self.v2aN.keys())):
                self.Gs[ff].add_node(i,label=self.v2aN[i])
                self.labelDict[i]=self.v2aN[i]
                self.pos[i]=self.v2aN[i]
            i+=1
            v2aN=deepcopy(self.v2aN)
            a2vN=deepcopy(self.a2vN)
            for bN in self.boundaryMap.keys():
                if bN[0]==0:
                    nodeLoc=(-1,bN[1])
                elif bN[0]==2*self.xElements:
                    nodeLoc=(2*self.xElements+1,bN[1])
                elif bN[1]==0:
                    nodeLoc=(bN[0],-1)
                elif bN[1]==2*self.yElements:
                    nodeLoc=(bN[0],2*self.yElements+1)
                self.Gs[ff].add_node(i,label=nodeLoc)
                self.labelDict[i]=nodeLoc
                v2aN[i]=nodeLoc
                a2vN[nodeLoc]=i
                self.pos[i]=nodeLoc
                i+=1
            for ind in range(0,len(self.e[ff]),2):
                fieldCoord=self.v2a[ind//2]
                sourceNodeCoord=(fieldCoord[0]-(fieldCoord[0]+1)%2,fieldCoord[1]-(fieldCoord[1]+1)%2)
                sourceNode=a2vN[sourceNodeCoord]
                targetNodeCoord=(fieldCoord[0]+(fieldCoord[0]+1)%2,fieldCoord[1]+(fieldCoord[1]+1)%2)
                targetNode=a2vN[targetNodeCoord]
                self.Gs[ff].add_edge(sourceNode,targetNode,weight=self.e[ff][ind])
                self.Gs[ff].add_edge(targetNode,sourceNode,weight=self.e[ff][ind+1])
        return

    def plot_system(self,freq):
        """
        Plots the graphed simulation results at frequency freq
        """
        options = {
            "font_size": 6,
            "node_size": 300,
            "node_color": "white",
            "edgecolors": "black",
            "linewidths": 1,
            "width": 1,
        }
        posInv={}
        maxx=np.max([v[0] for _,v in self.pos.items()])
        for k,v in self.pos.items():
            posInv[k]=(v[1],maxx-v[0])
        #nx.draw_networkx(self.G, self.pos, arrowstyle='-|>', arrowsize=np.abs(np.array(self.weights)), connectionstyle='arc3,rad=0.2', **options)
        nx.draw_networkx_nodes(self.Gs[freq], posInv, node_size=options["node_size"])

        # Draw the edges with width proportional to the edge weight
        for (u, v, d) in self.Gs[freq].edges(data=True):
            weight = np.abs(d['weight'])
            nx.draw_networkx_edges(
                self.Gs[freq], posInv, edgelist=[(u, v)],
                width=weight,  # Use edge weight for arrow width
                arrowstyle='-|>', arrowsize=15,
                connectionstyle='arc3,rad=0.2' if (u, v) != (v, u) else 'arc3,rad=-0.2'
            )

        # Draw the labels
        nx.draw_networkx_labels(self.Gs[freq], posInv, font_size=options["font_size"], font_family="sans-serif", labels=self.labelDict)
        ax = plt.gca()
        ax.margins(0.20)
        plt.axis("off")
        fig = matplotlib.pyplot.gcf()
        if self.plotSize is not None:
            fig.set_size_inches(self.plotSize[0],self.plotSize[1])
        plt.show()
        return

    def get_networkS(self):
        """
        Extracts the network S-parameters from the simulation results.
        """
        self.networkS={}
        for ff in self.e.keys():
            self.networkS[ff]={}
            ins,refs,outs,bndsIn,bndsOut=[],[],[],[],[]
            for bnd in self.boundaryMap.keys():
                bv=self.boundaryMap[bnd]
                if bv[0]=="input":
                    ins.append(bv[1])
                    node=self._boundaryField2Node(bnd)
                    aIn=self._ioc(node,bnd,fieldInd=0)
                    refs.append(self.e[ff][self.a2v[bnd]+int(aIn)])
                    bndsIn.append(bnd)
                elif bv[0]=="output":
                    node=self._boundaryField2Node(bnd)
                    aIn=self._ioc(node,bnd,fieldInd=0)
                    outs.append(self.e[ff][self.a2v[bnd]+int(aIn)])
                    bndsOut.append(bnd)
            for iM,rM,b in zip(ins,refs,bndsIn):
                self.networkS[ff][b]={b:rM/iM}
                for oM,bo in zip(outs,bndsOut):
                    self.networkS[ff][b][bo]=oM/iM
            if self.symmetryAxis=='x':
                for source in self.networkS[ff].keys():
                    targets=tuple(self.networkS[ff][source].keys())
                    for target in targets:
                        if (target[0]!=0 or target[1]!=self.yElements*2-1) and (target[0]!=self.eX[-1] or target[1]!=self.yElements*2-1):
                            self.networkS[ff][source][(target[0],self.yElements*4-2-target[1])]=self.networkS[ff][source][target]
            if self.symmetryAxis=='y':
                for source in self.networkS[ff].keys():
                    targets=tuple(self.networkS[ff][source].keys())
                    for target in targets:
                        if (target[1]!=0 or target[0]!=self.xElements*2-1) and (target[1]!=self.eY[-1] or target[0]!=self.xElements*2-1):
                            self.networkS[ff][source][(self.xElements*4-2-target[0],target[1])]=self.networkS[ff][source][target]
        return self.networkS

    def extractFieldsAt(self,freq,coords):
        """

        """
        fieldInd=self.a2v[coords]
        return self.e[ff][fieldInd:(fieldInd+2)]

    def plotSpectrum(self,nodeSet=[],tp='real',figsize=(6,6)):
        """
        Plots s-param spectrum.

        Arguments:
        nodeSet: List. List of in/out nodes to plot. Each element is a two-tuple ((x_in,y_in),(x_out,y_out))
        tp: String. Type of plot. 'real', 'imag', 'mag', 'phase', 'magdB'
        """
        processDict={'real':np.real,'imag':np.imag,'mag':np.abs,'phase':np.angle,'magdb':lambda x: 10*np.log10(np.abs(x)**2)}
        xs,ys,labels=[],[],[]
        for ns in nodeSet:
            xs.append([])
            ys.append([])
            labels.append(ns)
            n1,n2=ns
            for ff in self.networkS:
                ys[-1].append(processDict[tp.lower()](self.networkS[ff][n1][n2]))
                xs[-1].append(ff)
        fig,ax=plt.subplots(1,1,figsize=figsize)
        for x,y,l in zip(xs,ys,labels):
            ax.plot(x,y,label=str(l))
        ax.legend()
        ax.set_xlabel('Frequency')
        ax.set_ylabel("S-param ("+tp+")")
        plt.show()
        return

class micropatchSimObject(micropatchSim):
    def __init__(self):
        micropatchSim.__init__(self)
        self.augBoundary=True
        self.timings=[]
        return

    def add_ports(self,portLocations,portTypes,portParams,freq):
        '''
        portParams[f][0][i]= Target magnitude of S=|a|^2 at frequency f for port i.
        portParams[f][1][i]= Target phase in degrees of S=|a|e^{i*phase/180*pi} at frequency f for port i.
        portParams[f][2][i]= Weight on magntiude objective at frequency f for port i.
        portParams[f][3][i]= Weight on phase objective at frequency f for port i.
        portParams[f][4][i]= Equiphase target port at frequency f
        portParams[f][5][i]= Weight on equiphase objective at frequency f for port i.
        portParams[f][6][i]= EquiMag target port at frequency f
        portParams[f][7][i]= Weight on equiMag objective at frequency f for port i.
        portParams[f][8][i]= Weight on squared mag in port i at frequency f
        portParams[f][9][i]= Weight on inverse squared mag in port i at frequency f
        '''
        self.portLocations=portLocations
        self.portTypes=portTypes
        self.portParams=portParams
        self.portInfo={'portParams':[],'portLocations':[],'portTypes':[]}
        self.portInfo['portParams'].append(self.portParams)
        self.portInfo['portLocations'].append(self.portLocations)
        self.portInfo['portTypes'].append(self.portTypes)
        self.boundaryMap={}
        for pl,pt in zip(portLocations,portTypes):
            if pt=='input':
                self.boundaryMap[pl]=(pt,1)
            else:
                self.boundaryMap[pl]=(pt,)
        if not hasattr(freq,'__iter__'):
            freq=[freq,]
        self.ufreqs=freq
        return

    def add_sMats(self,files):
        if not hasattr(files,'__iter__'):
            files=[files,]
        for file in files:
            self.load_sMatrix(file)
        return

    def add_structure(self,setMap,symmetryAxis=None):
        '''
        Defines structure of the SDP problem. setMap should have a value of -1 for designable points, and the set number index elsewhere. Designable points will choose between set 0 and set 1.
        '''
        self.size=setMap.shape

        self.usetMap=setMap
        self.symmetryAxis=symmetryAxis
        self.set_structure(self.size[0],self.size[1],setMap,symmetryAxis=symmetryAxis)
        self.structSize=(self.xElements,self.yElements)
        return

    def compileSDP(self):
        self.auxFields=[]
        self.sizeOneFreq=(self.xElements*self.yElements*2+self.xElements*int(self.symmetryAxis!='x')+self.yElements*int(self.symmetryAxis!='y'))*2*2
        for j,f in enumerate(self.ufreqs):
            for i,pl in enumerate(self.portLocations):
                locR,locI=self.findPortOutIndex(pl,j)
                self.auxFields+=[locR,locI]*int(self.portParams[j][2,i]!=0)
                #if len(self.portParams[j])>4 and self.portParams[j][5,i]!=0:
                #    target=int(self.portParams[j][4,i])
                #    locRTarget,locITarget=self.findPortOutIndex(self.portLocations[target],j)
                #    self.auxFields+=[[locR,locITarget],[locI,locRTarget]]
        grandASize=[self.sizeOneFreq*len(self.ufreqs),self.sizeOneFreq*len(self.ufreqs)]
        self.grandAUp=np.zeros(grandASize)
        setMapUp=np.where(self.usetMap<0,1,self.usetMap)
        self.set_structure(self.size[0],self.size[1],setMap=setMapUp,symmetryAxis=self.symmetryAxis)
        self.set_boundary(boundaryMap=self.boundaryMap)
        for i,freq in enumerate(self.ufreqs):
            self.nodeMap=[]
            self.compile_structure(freq)
            self.saR=np.block([[np.real(self.A),-np.imag(self.A)],[np.imag(self.A),np.real(self.A)]])
            self.grandAUp[self.sizeOneFreq*(i):self.sizeOneFreq*(i+1),self.sizeOneFreq*(i):self.sizeOneFreq*(i+1)]=self.saR
        self.grandADown=np.zeros(grandASize)
        setMapDown=np.where(self.usetMap<0,0,self.usetMap)
        self.set_structure(self.size[0],self.size[1],setMap=setMapDown,symmetryAxis=self.symmetryAxis)
        self.set_boundary(boundaryMap=self.boundaryMap)
        self.grandNodeMap=[]
        self.grandb=np.zeros(self.sizeOneFreq*len(self.ufreqs))
        for i,freq in enumerate(self.ufreqs):
            self.nodeMap=[]
            self.ni=1
            self.compile_structure(freq)
            self.sbR=np.block([[np.real(self.A),-np.imag(self.A)],[np.imag(self.A),np.real(self.A)]])
            self.grandADown[self.sizeOneFreq*i:self.sizeOneFreq*(i+1),self.sizeOneFreq*i:self.sizeOneFreq*(i+1)]=self.sbR
            self.grandb[self.sizeOneFreq*(i):self.sizeOneFreq*(i+1)]=np.hstack([np.real(self.J),np.imag(self.J)])
            self.grandNodeMap+=deepcopy(self.nodeMap*2)
        self.sdp=SDPCore()
        self.sdp.system2SDP(self.grandADown,self.grandAUp,self.grandb,nodeMap=np.array(self.grandNodeMap),zeroFloor=1E-12,auxFields=self.auxFields)
        return self.sdp

    def compileA0(self):
        A0=np.zeros(self.sdp.constraints[0].shape)
        runningF=np.shape(self.grandAUp)[0]
        for j,pp in enumerate(self.portParams):
            for i,pL in enumerate(self.portLocations):
                locR,locI=self.findPortOutIndex(pL,j)
                if pp[3,i]!=0:
                    cPhase,sPhase=np.cos(np.pi*pp[1,i]/180),np.sin(np.pi*pp[1,i]/180)
                    m0=np.sqrt(pp[0,i])
                    A0[locR,locR]+=pp[3,i]
                    A0[locI,locI]+=pp[3,i]
                    A0[locR,-1]+=-pp[3,i]*m0*cPhase
                    A0[locI,-1]+=-pp[3,i]*m0*sPhase
                elif pp[2,i]!=0:
                    w=pp[2,i]
                    aR,aI=runningF,runningF+1
                    runningF+=2
                    m0=pp[0,i]
                    A0[aR,aR]+=w
                    A0[aI,aI]+=w
                    A0[aR,aI]+=w
                    A0[locR,locR]+=-2*m0*w
                    A0[locI,locI]+=-2*m0*w
                if len(pp)>4 and pp[5,i]!=0:
                    w=pp[5,i]
                    target=int(pp[4,i])
                    locRTarget,locITarget=self.findPortOutIndex(self.portLocations[target],j)
                    #aR,aI=runningF,runningF+1
                    #runningF+=2
                    #A0[aR,aR]=w
                    #A0[aI,aI]=w
                    #A0[aR,aI]=-1*w
                    A0[locR,locR]+=w
                    A0[locI,locI]+=w
                    A0[locRTarget,locRTarget]+=w
                    A0[locITarget,locITarget]+=w
                    minR,maxR=np.min((locR,locRTarget)),np.max((locR,locRTarget))
                    minI,maxI=np.min((locI,locITarget)),np.max((locI,locITarget))
                    A0[minR,maxR]+=-w
                    A0[minI,maxI]+=-w
        self.A0=np.transpose(np.triu(A0,k=1))+A0
        return self.A0

    def findPortOutIndex(self,port,freq):
        maxX,maxY=self.xElements*2,self.yElements*2

        rv=0
        if port[1]==0:
            rv= self.a2v[port]+int(not self._ioc(port,(port[0],1),fieldInd=0))+freq*self.sizeOneFreq
        elif port[0]==0:
            rv= self.a2v[port]+int(not self._ioc(port,(1,port[1]),fieldInd=0))+freq*self.sizeOneFreq
        elif port[1]==maxY:
            rv= self.a2v[port]+int(not self._ioc(port,(port[0],maxY-1),fieldInd=0))+freq*self.sizeOneFreq
        elif port[0]==maxX:
            rv=self.a2v[port]+int(not self._ioc(port,(maxX-1,port[1]),fieldInd=0))+freq*self.sizeOneFreq
        return rv,rv+self.sizeOneFreq//2

    def getSO(self,structureMat,useA0=True,sdpObj=False):
        '''
        portParams[f][0][i]= Target magnitude of S=|a|^2 at frequency f for port i.
        portParams[f][1][i]= Target phase in degrees of S=|a|e^{i*phase/180*pi} at frequency f for port i.
        portParams[f][2][i]= Weight on magntiude objective at frequency f for port i.
        portParams[f][3][i]= Weight on phase objective at frequency f for port i.
        portParams[f][4][i]= Equiphase target port at frequency f
        portParams[f][5][i]= Weight on equiphase objective at frequency f for port i.
        portParams[f][6][i]= EquiMag target port at frequency f
        portParams[f][7][i]= Weight on equiMag objective at frequency f for port i.
        portParams[f][8][i]= Phase ratio target port at frequency f
        portParams[f][9][i]= Weight on phase ratio objective at frequency f for port i.
        portParams[f][10][i]= Weight on squared mag in port i at frequency f
        portParams[f][11][i]= Weight on inverse squared mag in port i at frequency f
        '''
        if self.symmetryAxis=='x':
            structureMat=np.hstack((structureMat,np.flip(structureMat[:,:-1],axis=1)))
        if self.symmetryAxis=='y':
            structureMat=np.vstack((structureMat,np.flip(structureMat[:-1,:],axis=0)))
        self.set_structure(self.size[0],self.size[1],setMap=np.where(self.usetMap<0,structureMat,self.usetMap),symmetryAxis=self.symmetryAxis)
        #structureMat=np.where(self.usetMap<0,structureMat,self.usetMap
        '''
        fig,ax=plt.subplots(nrows=1,ncols=1,figsize=(4,4))
        ax.imshow(np.where(self.usetMap<0,structureMat,self.usetMap),cmap='Greys')
        plt.show()
        '''
        self.set_boundary(boundaryMap=self.boundaryMap)
        _,timing=self.solve_system(self.ufreqs)
        self.timings.append(timing)
        Sp=self.get_networkS()
        auxFieldVals=[]
        xvec=[]
        Ss=[]
        analyticObj=0
        inLoc=self.portLocations[0]
        for i,(frq,portParams) in enumerate(zip(self.ufreqs,self.portParams)):
            rads=portParams[1]/180*np.pi
            sin,cos=np.sin(rads),np.cos(rads)
            Ss.append([])
            if useA0:
                evec=self.e[frq]
                xff=list(evec.real)+list(evec.imag)
                auxFieldVals+=[xff[j]**2 for j in self.auxFields if j<self.sizeOneFreq]
                xvec+=xff
            relDict=Sp[frq][inLoc]
            for j,pL in enumerate(self.portLocations):
                Ss[-1].append(relDict[pL])
            Ss[-1]=np.array(Ss[-1])
            #print(Ss[-1])

            analyticObj+=np.sum(portParams[2]*((np.abs(Ss[-1])**2-portParams[0])**2-int(sdpObj)*portParams[0]**2)) #Magnitude objective

            analyticObj+=np.sum(portParams[3]*(np.abs(Ss[-1]-np.sqrt(portParams[0])*np.exp(1j*rads))**2-int(sdpObj)*(portParams[0]*cos**2+portParams[0]*sin**2))) #Phase objective

            delta=np.angle(Ss[-1])-np.angle(Ss[-1][portParams[4].astype(np.intp, copy=False)])
            delta = (delta + np.pi) % (2*np.pi) - np.pi
            analyticObj+=np.sum(portParams[5]*(delta)**2)
            if len(portParams)>6:
                analyticObj+=np.sum(portParams[7]*(np.abs(Ss[-1])-np.abs(Ss[-1][portParams[6].astype(np.intp, copy=False)]))**2)

                Rs=Ss[-1]/Ss[-1][portParams[8].astype(np.intp, copy=False)]
                analyticObj+=np.sum(portParams[9]*np.abs(Rs-np.exp(1j*rads))**2)

                analyticObj+=np.sum(portParams[10]*np.abs(Ss[-1])**2)
                analyticObj+=np.sum(portParams[11]/np.abs(Ss[-1])**2)

        if useA0:
            xvec+=auxFieldVals
            xvec=np.hstack((np.array(xvec),np.array((1))))
            return np.trace(self.A0 @ np.outer(xvec,xvec)),Ss
        else:
            return analyticObj,Ss

def touchstone2array(filename):
    """
    Read an N-port Touchstone file (extension .sNp or .snp) and return a dict:
        { frequency_float:  N×N complex‐valued S-matrix (numpy.ndarray) }

    - Skips comment lines beginning with '!' and the option‐header line beginning with '#'.
    - Supports data formats RI, MA, and DB (given by the 4th token on the '#' line).
    - For N = 1 or 2, expects all data for each frequency on a single line.
    - For N ≥ 3, expects data in matrix form: first row on one line (freq + 2N values),
      then the remaining N−1 rows on successive non‐comment lines (each with 2N values).
    """
    # Helper: convert one (v0, v1) pair to complex, depending on data_format
    def pair_to_complex(v0, v1, data_format):
        if data_format == 'RI':
            # Real/Imaginary
            real = float(v0)
            imag = float(v1)
            return real + 1j * imag
        elif data_format == 'MA':
            # Magnitude / Angle (degrees)
            mag = float(v0)
            ang_deg = float(v1)
            return mag * np.exp(1j * np.deg2rad(ang_deg))
        elif data_format == 'DB':
            # dB / Angle (degrees) → convert dB ▶ linear magnitude
            db = float(v0)
            ang_deg = float(v1)
            mag = 10 ** (db / 20.0)
            return mag * np.exp(1j * np.deg2rad(ang_deg))
        else:
            raise ValueError(f"Unsupported data format: '{data_format}'")

    # Read all lines, strip newline characters
    with open(filename, 'r') as f:
        raw_lines = f.readlines()

    # Parse header: skip all lines until we find the option line (starts with '#')
    data_format = None
    idx = 0
    while idx < len(raw_lines):
        line = raw_lines[idx].strip()
        if not line or line.startswith('!'):
            idx += 1
            continue
        if line.startswith('#'):
            tokens = line.lstrip('#').strip().upper().split()
            # tokens[0] = frequency unit, tokens[1] = 'S' (we only handle scattering),
            # tokens[2] = data format (RI, MA, or DB), tokens[3:] may include 'R' and ref_impedance
            if len(tokens) < 3:
                raise ValueError("Malformed option line (missing data format).")
            data_format = tokens[2]
            idx += 1
            break
        else:
            raise ValueError("Expected option line beginning with '#', but found:\n  " + line)

    if data_format not in {'RI', 'MA', 'DB'}:
        raise ValueError(f"Option line specifies unsupported data format '{data_format}'")

    # Now idx points to the first line after the option line. We'll iterate through lines
    sData = {}
    # Outer loop: scan until end of file
    while idx < len(raw_lines):
        line = raw_lines[idx].strip()
        if not line or line.startswith('!'):
            idx += 1
            continue

        # First non‐comment line: interpret as start of a data block for one frequency
        tokens = line.split()
        # Infer number of ports N from the number of numeric tokens:
        #   For each data line, #tokens = 1 (freq) + 2*N  if N ≤ 2 (all pairs on one line)
        #   For N ≥ 3, the first data row is: 1 (freq) + 2*N entries
        # Hence N = (len(tokens) - 1) // 2
        if len(tokens) < 3:
            raise ValueError(f"Data line too short to infer ports: '{line}'")
        N = (len(tokens) - 1) // 2
        if N < 1:
            raise ValueError(f"Cannot infer valid port count from tokens: {tokens}")

        # Handle N=1 or N=2 (all data on one line):
        if N <= 2:
            freq = float(tokens[0])
            # There should be exactly 2 * (N*N) numeric values after freq
            expected_pairs = N * N
            if len(tokens) != 1 + 2 * expected_pairs:
                raise ValueError(
                    f"Expected {1 + 2*expected_pairs} tokens for {N}-port single-line entry, "
                    f"but found {len(tokens)}: '{line}'"
                )
            # Build an empty S-matrix
            smat = np.zeros((N, N), dtype=complex)
            # Extract all pairs in the order they appear
            # For N=1: order = [ S11 ]
            # For N=2: order = [ S11, S21, S12, S22 ]  (column-major!) :contentReference[oaicite:0]{index=0}
            raw_vals = tokens[1:]  # length = 2 * (N*N)
            pairs = []
            for k in range(expected_pairs):
                v0 = raw_vals[2*k]
                v1 = raw_vals[2*k + 1]
                pairs.append(pair_to_complex(v0, v1, data_format))
            if N == 1:
                smat[0, 0] = pairs[0]
            else:  # N == 2
                # column-major assignment: (row, col)
                smat[0, 0] = pairs[0]  # S11
                smat[1, 0] = pairs[1]  # S21
                smat[0, 1] = pairs[2]  # S12
                smat[1, 1] = pairs[3]  # S22
            sData[freq] = smat
            idx += 1
            continue

        # Otherwise N >= 3: first line holds row 1 (freq + 2*N values)
        #   then the next N-1 non‐comment lines each hold 2*N values for rows 2..N :contentReference[oaicite:1]{index=1}
        freq = float(tokens[0])
        row_tokens = tokens[1:]
        if len(row_tokens) != 2 * N:
            raise ValueError(
                f"Expected {2*N} data tokens for port‐row 1, but got {len(row_tokens)}: '{line}'"
            )

        # Initialize S-matrix
        smat = np.zeros((N, N), dtype=complex)
        # Fill in row 1 (i = 0)
        for col in range(N):
            v0 = row_tokens[2*col]
            v1 = row_tokens[2*col + 1]
            smat[0, col] = pair_to_complex(v0, v1, data_format)

        # Read the remaining N−1 rows
        row_count = 1
        idx += 1
        while row_count < N and idx < len(raw_lines):
            next_line = raw_lines[idx].strip()
            if not next_line or next_line.startswith('!'):
                idx += 1
                continue
            row_vals = next_line.split()
            if len(row_vals) != 2 * N:
                raise ValueError(
                    f"Expected {2*N} data tokens for port‐row {row_count+1}, but got {len(row_vals)}: '{next_line}'"
                )
            for col in range(N):
                v0 = row_vals[2*col]
                v1 = row_vals[2*col + 1]
                smat[row_count, col] = pair_to_complex(v0, v1, data_format)
            row_count += 1
            idx += 1

        if row_count != N:
            raise ValueError(
                f"Ran out of lines before gathering all {N} rows for frequency {freq}"
            )

        sData[freq] = smat

    return sData
def processSetMap(portLocations,setMap):
    setMap=np.pad(setMap,((1,1),(1,1)),'constant',constant_values=0)
    portLocations2=[]
    for pl in portLocations:
        if pl[0]==0:
            portLocations2.append((pl[0],pl[1]+2))
            setMap[portLocations2[-1][0]//2,portLocations2[-1][1]//2]=2
        elif pl[1]==0:
            portLocations2.append((pl[0]+2,pl[1]))
            setMap[portLocations2[-1][0]//2,portLocations2[-1][1]//2]=2
        elif pl[0]==(setMap.shape[0]-2)*2:
            portLocations2.append((pl[0]+4,pl[1]+2))
            setMap[portLocations2[-1][0]//2-1,portLocations2[-1][1]//2]=2
        elif pl[1]==(setMap.shape[1]-2)*2:
            portLocations2.append((pl[0]+2,pl[1]+4))
            setMap[portLocations2[-1][0]//2,portLocations2[-1][1]//2-1]=2
    return portLocations2,setMap

def buildMSOCPW(mso,setMap,portLocations2,symmetryAxis,portTypes,portParams,freq,lossless=False):
    mso.add_structure(setMap,symmetryAxis=symmetryAxis) #We now add the setMap to mso
    #This is where we define port locations (using the grid, not the vector), the type, load up out portParams, and determine frequency (or frequencies)
    mso.add_ports(portLocations=portLocations2,portTypes=portTypes,portParams=portParams,freq=freq)
    mso.add_sMats(['/home/groundnet/Desktop/Nate/convexPreopt/element4LFreeCPWPEC_F.snp','/home/groundnet/Desktop/Nate/convexPreopt/element4LFreeCPWPEC.snp']) #coptEnv
    mso.sMats[2]={}
    for fr in mso.freqs:
        mso.sMats[2][fr]=np.array([[0,0,0,1],[0,0,1,0],[0,1,0,0],[1,0,0,0]])
    mso.setName=3
    mso.add_sMats(['/home/groundnet/Desktop/Nate/convexPreopt/element4LFreeCPWPEC_12p5In.snp'])
    if lossless:
        for fr in mso.freqs:
            for l in range(2):
                mso.sMats[l][fr]=scipy.linalg.polar(mso.sMats[l][fr])[0]
            mso.sMats[3][fr]=scipy.linalg.polar(mso.sMats[3][fr])[0]
    return mso
def draw_pcb(ax,pattern):
    """
    Render a 15×15 micropatch array.

    Parameters
    ----------
    pattern : array‑like (15, 15) with entries {0, 1, 2}
        0 – empty
        1 – crossed bars + centre circle
        2 – single bar:
            horizontal  if ((y>x  and y<15‑x) or (y>15‑x and y<x))
            vertical    otherwise
        with (x, y) measured from bottom‑left, 0‑based.
    """
    shape=pattern.shape
    pattern = np.asarray(pattern)

    # geometry & colours
    cell, bar, gap = 1.5, 0.3, 0.2
    copper, pcb_green = '#b87333', '#0a4721'
    ground='#82766b'
    ax.set_xlim(0, shape[1] * cell)
    ax.set_ylim(0, shape[0] * cell)
    ax.set_aspect('equal')
    ax.set_facecolor(pcb_green)
    ax.axis('off')

    for r in range(shape[0]):            # r = row index (top → bottom)
        for c in range(shape[1]):        # c = column index (left → right)
            val = pattern[r, c]


            # convert to bottom‑left origin for rule tests
            xcell, ycell = c, shape[0]-1 - r
            x0, y0 = c * cell, ycell * cell
            if val==0 and r!=0 and r!=shape[0]-1 and c!=0 and c!=shape[1]-1:
                ax.add_patch(Rectangle((x0+gap, y0+gap),
                                        cell-2*gap, cell-2*gap, facecolor=ground, lw=0))
                ax.add_patch(Rectangle((x0 , y0),
                                        cell/2-bar/2-gap, cell/2-bar/2-gap, facecolor=ground, lw=0))
                ax.add_patch(Rectangle((x0+cell/2+bar/2+gap , y0),
                                        cell/2-bar/2-gap, cell/2-bar/2-gap, facecolor=ground, lw=0))
                ax.add_patch(Rectangle((x0+cell/2+bar/2+gap , y0+cell/2+bar/2+gap),
                                        cell/2-bar/2-gap, cell/2-bar/2-gap, facecolor=ground, lw=0))
                ax.add_patch(Rectangle((x0 , y0+cell/2+bar/2+gap),
                                        cell/2-bar/2-gap, cell/2-bar/2-gap, facecolor=ground, lw=0))
            elif val == 1:           # crossed bars + circle
                ax.add_patch(Rectangle((x0, y0 + (cell - bar)/2),
                                        cell, bar, facecolor=copper, lw=0))
                ax.add_patch(Rectangle((x0 + (cell - bar)/2, y0),
                                        bar, cell, facecolor=copper, lw=0))

                ax.add_patch(Rectangle((x0 , y0),
                                        cell/2-bar/2-gap, cell/2-bar/2-gap, facecolor=ground, lw=0))
                ax.add_patch(Rectangle((x0+cell/2+bar/2+gap , y0),
                                        cell/2-bar/2-gap, cell/2-bar/2-gap, facecolor=ground, lw=0))
                ax.add_patch(Rectangle((x0+cell/2+bar/2+gap , y0+cell/2+bar/2+gap),
                                        cell/2-bar/2-gap, cell/2-bar/2-gap, facecolor=ground, lw=0))
                ax.add_patch(Rectangle((x0 , y0+cell/2+bar/2+gap),
                                        cell/2-bar/2-gap, cell/2-bar/2-gap, facecolor=ground, lw=0))

            elif val == 2:         # single bar
                horiz = ((ycell > xcell and ycell < shape[1] - xcell) or
                         (ycell > shape[0] - xcell and ycell < xcell))
                if horiz:          # horizontal bar
                    ax.add_patch(Rectangle((x0, y0 + (cell - bar)/2),
                                            cell, bar, facecolor=copper, lw=0))
                    ax.add_patch(Rectangle((x0, y0),
                                            cell, cell/2-bar/2-gap, facecolor=ground, lw=0))
                    ax.add_patch(Rectangle((x0, y0+cell/2+bar/2+gap),
                                            cell, cell/2-bar/2-gap, facecolor=ground, lw=0))
                else:              # vertical bar
                    ax.add_patch(Rectangle((x0 + (cell - bar)/2, y0),
                                            bar, cell, facecolor=copper, lw=0))
                    ax.add_patch(Rectangle((x0, y0),
                                            cell/2-bar/2-gap,cell, facecolor=ground, lw=0))
                    ax.add_patch(Rectangle((x0+cell/2+bar/2+gap, y0),
                                            cell/2-bar/2-gap,cell, facecolor=ground, lw=0))

    return ax
def parseTradResults(ffn):
    ff=open(ffn,'rb')
    po=pickle.load(ff)
    ff.close()
    usepo=po
    bestSet,bestv=(0,0,0),np.inf
    for rSeed,rss in enumerate(po):
        for thread, ts in enumerate(rss):
            useStep=None
            thisBest=ts[1][-1][0]
            if ts[1][-2][0]<thisBest:
                thisBest=ts[1][-2][0]
                useStep=-1
            if thisBest<bestv:
                bestv=deepcopy(thisBest)
                bestSet=(rSeed,thread,useStep)
    return po[bestSet[0]][bestSet[1]][0][-1],po[bestSet[0]][bestSet[1]][2],[v[0] for v in po[bestSet[0]][bestSet[1]][1][:bestSet[2]]]
ex1x1=np.array([[1,]])
ex1x2=np.array([[1,1]])
ex3x2=np.array([[0,1],
                [1,1],
                [0,1]])
ex3x3=np.array([[0,1,0],
                [1,1,1],
                [0,1,0]])
ex5x4=np.array([[0,0,1,0],
                [0,1,1,0],
                [1,1,1,1],
                [0,1,1,0],
                [0,0,1,0]])
ex5x5=np.array([[0,0,1,0,0],
                [0,1,1,0,0],
                [1,1,1,1,1],
                [0,1,1,0,0],
                [0,0,1,0,0]])
ex7x6=np.array([[0,0,0,1,0,0],
                [0,0,1,1,0,0],
                [0,1,1,0,0,0],
                [1,1,1,1,1,1],
                [0,1,1,0,0,0],
                [0,0,1,1,0,0],
                [0,0,0,1,0,0],])
ex7x7=np.array([[0,0,0,1,0,0,0],
                [0,0,1,1,0,0,0],
                [0,1,1,0,0,0,0],
                [1,1,1,1,1,1,1],
                [0,1,1,0,0,0,0],
                [0,0,1,1,0,0,0],
                [0,0,0,1,0,0,0],])
ex9x8=np.array([[0,0,0,0,1,0,0,0],
                [0,0,0,1,1,0,0,0],
                [0,0,1,1,0,0,0,0],
                [0,1,1,0,0,0,0,0],
                [1,1,1,1,1,1,1,1],
                [0,1,1,0,0,0,0,0],
                [0,0,1,1,0,0,0,0],
                [0,0,0,1,1,0,0,0],
                [0,0,0,0,1,0,0,0],])
ex9x9=np.array([[0,0,0,0,1,0,0,0,0],
                [0,0,0,1,1,0,0,0,0],
                [0,0,1,1,0,0,0,0,0],
                [0,1,1,0,0,0,0,0,0],
                [1,1,1,1,1,1,1,1,1],
                [0,1,1,0,0,0,0,0,0],
                [0,0,1,1,0,0,0,0,0],
                [0,0,0,1,1,0,0,0,0],
                [0,0,0,0,1,0,0,0,0],])
ex11x10=np.array([[0,0,0,0,0,1,0,0,0,0],
                  [0,0,0,0,1,1,0,0,0,0],
                  [0,0,0,1,1,0,0,0,0,0],
                  [0,0,1,1,0,0,0,0,0,0],
                  [0,1,1,0,0,0,0,0,0,0],
                  [1,1,1,1,1,1,1,1,1,1],
                  [0,1,1,0,0,0,0,0,0,0],
                  [0,0,1,1,0,0,0,0,0,0],
                  [0,0,0,1,1,0,0,0,0,0],
                  [0,0,0,0,1,1,0,0,0,0],
                  [0,0,0,0,0,1,0,0,0,0],])
def runTimingEx(timingEx):
    teBase=-np.ones_like(timingEx)
    teBase=np.pad(teBase,((1,1),(1,1)),'constant',constant_values=0)
    te=np.pad(timingEx,((1,1),(1,1)),'constant',constant_values=0)
    txShape=te.shape
    lls=[(0,txShape[1]//2),(txShape[0]-1,txShape[1]//2),(txShape[0]//2,txShape[1]-1),(txShape[0]//2,0)]
    for ll in lls:
        teBase[ll[0],ll[1]]=2
    portLocations2=[(0,txShape[1]+(1-txShape[1]%2)),(txShape[0]*2,txShape[1]+(1-txShape[1]%2)),(txShape[0]+(1-txShape[0]%2),txShape[1]*2),(txShape[0]+(1-txShape[0]%2),0)]
    mso=micropatchSimObject() #Instantiate the mso object
    freqs=np.arange(5.1,15.1,0.1)
    portParams=[np.array([[0,1,0,0],[0,0,0,0],[1,3,1,1],[0,0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0]]),]*len(freqs)
    
    mso=buildMSOCPW(mso,teBase,portLocations2,symmetryAxis=None,portTypes=['input','output','output','output'],portParams=portParams,freq=freqs,lossless=False)
    t0=datetime.datetime.now()
    mso.useSparse=False
    ss=mso.getSO(te,useA0=False,sdpObj=False)
    dt=datetime.datetime.now()-t0
    avgUtil=np.mean([t[1] for t in mso.timings[0]])
    avgMem=np.mean([t[2] for t in mso.timings[0]])/ 1024**3 
    totTime=mso.timings[0][-1][0]-mso.timings[0][0][0]
    #fig,ax=plt.subplots(nrows=1,ncols=1,figsize=(4,4))
    #ax=draw_pcb(ax,mso.setMap)
    #ax.set_axis('off')
    #plt.show()
    print('Total time including matrix build and I/O: '+str(dt.total_seconds()))
    print('Time spent on solver alone: '+str(np.sum(mso.ts)))
    print('Time per frequency: '+str(np.mean(mso.ts)))
    print('Average CPU util from parent and children during solve: '+str(avgUtil)+'%')
    print('Average memory use by parent and children during solve: '+str(avgMem)+' GB')
    return mso
mso=runTimingEx(ex3x2)
